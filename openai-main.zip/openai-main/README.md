# Build and Deploy Your Own ChatGPT AI Application

this script is owned by Paul the cute coder
